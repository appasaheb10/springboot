package com.SpringBootClient;

import java.io.IOException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestClientException;

@SpringBootApplication
public class SpringBootClientApplication {

	public static void main(String[] args) {
		ApplicationContext ctx = 	
		SpringApplication.run(SpringBootClientApplication.class, args);
		ConsumerClient consumerClient = ctx.getBean(ConsumerClient.class);
		
		try {
			consumerClient.getEmployee();
			consumerClient.getEmployeeDetail();
			consumerClient.updateUser();
		} catch (RestClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Bean
	public ConsumerClient consumerClient(){
		return new ConsumerClient();
	}
}

package com.SpringBootClient;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;

import org.apache.catalina.connector.Response;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

public class ConsumerClient {

	
	
	public void getEmployee() throws RestClientException, IOException{
		String baseUrl = "http://localhost:8080/appasaheb/Userlist";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		try{
			
			response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		}catch(Exception e){
		 System.out.println(e);
		}
		
		
		System.out.println(response.getBody());
		
	}
	
	
	public void getEmployeeDetail() throws RestClientException,IOException{
		String baseUrl = "http://localhost:8080/appasaheb/Userlist";
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		
		try{
			
			response = restTemplate.exchange(baseUrl, HttpMethod.GET, getHeaders(), String.class);
		}catch(Exception e){
		 System.out.println(e);
		}
		System.out.println(response.getBody());
	}
	
	private static HttpEntity<?> getHeaders() throws IOException{
		HttpHeaders headers = new HttpHeaders();
		headers.set("Accept", MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity(headers);
	}
	
	
	
	public void updateUser() throws RestClientException, IOException{
		String baseUrl = "http://localhost:8080/appasaheb/Userlist";
		URI uri = null;
		try {
			uri = new URI(baseUrl);
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> response = null;
		//String jsonUser = "{"id":1,"firstName":"Appasaheb","lastName":"Neelawani","email":"appasaheb@gmail.com","password":"abc@12"}";
		try{
			UserDetails  userDetails = new UserDetails(1,"Shresta","Neelawani","appasaheb.gmail.com", "abc@123");
			response = restTemplate.postForEntity(uri, userDetails, String.class);
		}catch(Exception e){
		 System.out.println(e);
		}
		
		
		System.out.println(response.getBody());
		
	}
	
	
}

package com.SpringBootJPA.service;

import java.util.List;

import com.SpringBootJPA.model.UserDetails;

public interface UserService {
	
	public List<UserDetails> getUserDetails();
	
public void updateUser(UserDetails userDetails);
	
	public void createUser(UserDetails userDetails);

}

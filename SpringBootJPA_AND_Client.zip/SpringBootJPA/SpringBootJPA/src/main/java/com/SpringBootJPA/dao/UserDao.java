package com.SpringBootJPA.dao;

import java.util.List;

import com.SpringBootJPA.model.UserDetails;

public interface UserDao {
	public List<UserDetails> getUserDetails();
	
	public void updateUser(UserDetails userDetails);
	
	public void createUser(UserDetails userDetails);
}

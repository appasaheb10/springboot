package com.SpringBootJPA.controller;

import java.util.List;

import javax.security.auth.message.callback.PrivateKeyCallback.Request;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.SpringBootJPA.model.UserDetails;
import com.SpringBootJPA.service.UserService;


@Controller
public class UserController {

	@Autowired
	private UserService userService;
	
	
	@RequestMapping( value="/Userlist", method = RequestMethod.GET )
	public ResponseEntity getUserDetails(){
		List<UserDetails> userDetails = userService.getUserDetails(); 
		return new ResponseEntity(userDetails, HttpStatus.OK);
	}
	
	
	@RequestMapping( value="/Userlist", method = RequestMethod.PUT )
	public ResponseEntity updateUserDetails(UserDetails userDetails){
		userService.updateUser(userDetails); 
		return new ResponseEntity(userDetails, HttpStatus.OK);
	}
	
	@RequestMapping( value="/Userlist", method = RequestMethod.POST )
	public ResponseEntity createUserDetails(UserDetails userDetails){
		userService.updateUser(userDetails); 
		return new ResponseEntity(userDetails, HttpStatus.OK);
	}
}

package com.SpringBootJPA.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.SpringBootJPA.dao.UserDao;
import com.SpringBootJPA.model.UserDetails;
import com.SpringBootJPA.service.UserService;

@Component
public class UserServiceImpl implements UserService {

	@Autowired
	UserDao userDao;
	
	public List<UserDetails> getUserDetails(){
		return userDao.getUserDetails();
	}
	
	public void updateUser(UserDetails userDetails){
		userDao.updateUser(userDetails);
	}
	
	public void createUser(UserDetails userDetails){
		userDao.createUser(userDetails);
	}
}

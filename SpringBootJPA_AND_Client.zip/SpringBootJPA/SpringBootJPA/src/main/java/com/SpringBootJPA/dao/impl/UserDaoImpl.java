package com.SpringBootJPA.dao.impl;

import java.util.List;

import javax.persistence.EntityManagerFactory;
import javax.transaction.Transactional;

import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.SpringBootJPA.dao.UserDao;
import com.SpringBootJPA.model.UserDetails;

@Component
public class UserDaoImpl implements UserDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private EntityManagerFactory entityManagerFactory;

	public List<UserDetails> getUserDetails(){
		//Criteria criteria = sessionFactory.openSession().createCriteria(UserDetails.class);
		//return criteria.list();
		
		return entityManagerFactory.createEntityManager().createQuery("from UserDetails u").getResultList();
	}
	

	public void updateUser(UserDetails userDetails){
		UserDetails oldUserDetails =  (UserDetails) entityManagerFactory.createEntityManager().createQuery("from UserDetails u").getSingleResult();
		userDetails.setFirstName(userDetails.getFirstName());
		sessionFactory.openSession().save(userDetails);
	}
	
	
	public void createUser(UserDetails userDetails){
		entityManagerFactory.createEntityManager().persist(userDetails);
	}

}

package com.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelperController {

	
	
	@RequestMapping("/register.htm")
	public ModelAndView register(@RequestParam("nm") String name,@RequestParam("password") String password ,
			@RequestParam("email") String email , @RequestParam("address") String address){
		
		ModelAndView mv = new ModelAndView();
		mv.addObject("sg1", name);
		mv.addObject("sg2", password);
		mv.addObject("sg3", email);
		mv.addObject("sg4", address);
		mv.setViewName("result.jsp");
		
		return mv;
	}
	
	
public ModelAndView login(){
		
		ModelAndView mv = new ModelAndView();
		return mv;
	}
	
}

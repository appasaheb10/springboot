package com.firstbootproject.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.firstbootproject.entity.Employee;


@RestController
public class HelperController {

	@RequestMapping("allemployee")
	public List<Employee> getAll(){
		List<Employee> el = new ArrayList<Employee>();
		
		Employee e1 = new Employee("Appasaheb", "abc", "abc@gmail.com", "AAAA");
		el.add(e1);
		
		return el;
	}
}

package com.banu.aspectj;

public class Emailer {
	public void send(String dest, String msg)
	{
		System.out.println(msg  + "  sent to " + dest);
		try {
			Thread.sleep((long) (Math.random()*2000));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

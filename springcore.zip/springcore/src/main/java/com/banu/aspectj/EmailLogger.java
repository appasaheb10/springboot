package com.banu.aspectj;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class EmailLogger {
	@Before("execution(* send(String, String)) and args(address, *)")
	public void log(JoinPoint.StaticPart tjpsp, String address) {
		System.out.println("Invoking " + tjpsp.getSignature().getName() + " for "
				+ address);
	}
//	@AfterReturning("execution(* send(String, String))")
	@AfterReturning("execution(* com.banu.aspectj..*(..))")
	public void doAccessCheck() {
		System.out.println("After Returning .. Log");
	}
	
	
	@Around("execution(* com.banu.aspectj..*(..))")
	public Object doBasicProfiling(ProceedingJoinPoint pjp) throws Throwable {
	 long t1 = System.currentTimeMillis();
	Object retVal = pjp.proceed();
	long t2 = System.currentTimeMillis();
	System.out.println(pjp.getStaticPart().getSignature().getName() + " Took :" + (t2-t1) + "secs");
	return retVal;
	}
}

package com.banu.aspectj;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;



/**
 * @author BanuPrakash
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Main {

	public static void main(String[] args) {
	      ApplicationContext context = new ClassPathXmlApplicationContext("com/banu/aspectj/ApplicationContext.xml");
		 
	      Emailer emailer = (Emailer)context.getBean("emailer");
	      emailer.send("banu@advantech.com", 
	                   "Hi! Swing with Spring...");
	      emailer.send("rahul@advantech.com", 
	                   "Hi, I have an AspectJ question...");


	}
}

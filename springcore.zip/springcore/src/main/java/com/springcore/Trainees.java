package com.springcore;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@Component("def")
public class Trainees {
			
	@Autowired
	private Trainer trainerObject;
	
	/*public Trainer getTrainerObject() {
		return trainerObject;
	}

	public void setTrainerObject(Trainer trainerObject) {  //Adapter
		this.trainerObject = trainerObject;
	}
*/
	public void userTrainer(){
		trainerObject.teach();
	}

	public static void main(String[] args) {
		
		//Trainer t1 = new Trainer(); // spring work
		//Trainees tt = new Trainees();
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("first.xml");
		Trainees tt = (Trainees) ctx.getBean("def");
		
		//tt.setTrainerObject(t1);   //DI
		tt.userTrainer();
		
	}
	
}

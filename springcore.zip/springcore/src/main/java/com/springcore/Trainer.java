package com.springcore;

import org.springframework.stereotype.Component;

@Component
public class Trainer {

	
	public void teach(){
		System.out.println("Teaching Microservices");
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
